local bot = require('otouto.bot')

local instance = {
    config = require('config')
}

return bot.run(instance)
